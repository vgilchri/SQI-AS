# SQISign: compact post-quantum signatures from quaternions and isogenies

This code implements the isogeny-based signature scheme SQISign.

(C) 2020, The SQISign team. MIT license.


## Compile

To compile and test sqisign, run

```
make sqisign
```
For routine tests on Montgomery curves arithmetic and isogenies, run

```
make test
```
